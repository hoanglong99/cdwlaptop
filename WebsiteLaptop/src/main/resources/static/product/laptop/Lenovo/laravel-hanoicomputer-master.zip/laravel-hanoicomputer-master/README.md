# Clone backend website https://www.hanoicomputer.vn
* Xây dựng database cho nhiều loại sản phẩm có các thông số kĩ thuật khác nhau
* Login/Register admin, user
* CRUD product, category, filter,...
* Tính năng giỏ hàng sử dụng Session
* Tính năng filter sản phẩm
* Giao diện frontend sử dụng sẵn của website
Công nghệ: Laravel, mySQL, Bootstrap

<img src="https://github.com/hieuxc/laravel-hanoicomputer/blob/master/public/hnc/1.png" 
data-canonical-src="https://gyazo.com/eb5c5741b6a9a16c692170a41a49c858.png" width="400" />
<img src="https://github.com/hieuxc/laravel-hanoicomputer/blob/master/public/hnc/2.png" 
data-canonical-src="https://gyazo.com/eb5c5741b6a9a16c692170a41a49c858.png" width="400" />
<img src="https://github.com/hieuxc/laravel-hanoicomputer/blob/master/public/hnc/3.png" 
data-canonical-src="https://gyazo.com/eb5c5741b6a9a16c692170a41a49c858.png" width="400" />
<img src="https://github.com/hieuxc/laravel-hanoicomputer/blob/master/public/hnc/4.png" 
data-canonical-src="https://gyazo.com/eb5c5741b6a9a16c692170a41a49c858.png" width="400" />
<img src="https://github.com/hieuxc/laravel-hanoicomputer/blob/master/public/hnc/5.png" 
data-canonical-src="https://gyazo.com/eb5c5741b6a9a16c692170a41a49c858.png" width="400" />
<img src="https://github.com/hieuxc/laravel-hanoicomputer/blob/master/public/hnc/6.png" 
data-canonical-src="https://gyazo.com/eb5c5741b6a9a16c692170a41a49c858.png" width="400" />
<img src="https://github.com/hieuxc/laravel-hanoicomputer/blob/master/public/hnc/7.png" 
data-canonical-src="https://gyazo.com/eb5c5741b6a9a16c692170a41a49c858.png" width="400" />
<img src="https://github.com/hieuxc/laravel-hanoicomputer/blob/master/public/hnc/8.png" 
data-canonical-src="https://gyazo.com/eb5c5741b6a9a16c692170a41a49c858.png" width="400" />
